import { type NextRequest, NextResponse } from "next/server"

const bankTransactions = [
  { id: "1", description: "Starbucks Coffee", amount: 5.5, date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000) },
  {
    id: "2",
    description: "Uber Ride",
    amount: 12.5,
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
  },
  {
    id: "3",
    description: "Grocery Store",
    amount: 45.3,
    date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
  },
  {
    id: "4",
    description: "Netflix Subscription",
    amount: 15.99,
    date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
  },
  { id: "5", description: "Gym Membership", amount: 49.99, date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) },
  {
    id: "6",
    description: "Amazon Purchase",
    amount: 35.2,
    date: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000),
  },
  {
    id: "7",
    description: "Restaurant Dinner",
    amount: 62.5,
    date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
  },
  {
    id: "8",
    description: "Electric Bill",
    amount: 120,
    date: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000),
  },
  {
    id: "9",
    description: "Movie Tickets",
    amount: 28,
    date: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000),
  },
  {
    id: "10",
    description: "Doctor Appointment",
    amount: 150,
    date: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
  },
]

export async function GET(request: NextRequest) {
  try {
    return NextResponse.json({
      success: true,
      transactions: bankTransactions,
      message: "Transactions imported from connected bank account",
    })
  } catch (error) {
    return NextResponse.json({ message: "Failed to import transactions" }, { status: 500 })
  }
}
