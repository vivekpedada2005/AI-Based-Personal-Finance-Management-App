"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingDown, TrendingUp, Target, Wallet } from "lucide-react"

export function ExpenseSummary({ user, transactions }: { user: any; transactions: any[] }) {
  const salary = user?.salary || 50000
  const totalSpending = transactions.reduce((sum, t) => sum + t.amount, 0)
  const currentSavings = salary - totalSpending
  const budgetRemaining = Math.max(salary - totalSpending, 0)
  const availableBalance = salary + currentSavings

  const summaryData = [
    {
      title: "Total Spending",
      value: `₹${totalSpending.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`,
      change: `${((totalSpending / salary) * 100).toFixed(1)}% of salary`,
      icon: TrendingDown,
      color: "text-destructive",
    },
    {
      title: "Current Savings",
      value: `₹${currentSavings.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`,
      change: `${((currentSavings / salary) * 100).toFixed(1)}% saved`,
      icon: TrendingUp,
      color: "text-green-600",
    },
    {
      title: "Budget Remaining",
      value: `₹${budgetRemaining.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`,
      change: `This month`,
      icon: Target,
      color: "text-primary",
    },
    {
      title: "Available Balance",
      value: `₹${availableBalance.toLocaleString("en-IN", { maximumFractionDigits: 0 })}`,
      change: "Salary + Savings",
      icon: Wallet,
      color: "text-accent",
    },
  ]

  return (
    <>
      {summaryData.map((item, index) => (
        <Card key={index} className="border-primary/10 hover:border-primary/30 transition-colors">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{item.title}</CardTitle>
            <item.icon className={`w-5 h-5 ${item.color}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{item.value}</div>
            <p className="text-xs text-muted-foreground">{item.change}</p>
          </CardContent>
        </Card>
      ))}
    </>
  )
}
