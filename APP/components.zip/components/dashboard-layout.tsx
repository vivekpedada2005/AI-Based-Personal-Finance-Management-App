"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Menu, X, LogOut, Home, TrendingUp, Target, Settings, MessageCircle, TrendingDown, Zap } from "lucide-react"

export function DashboardLayout({ children, user }: { children: React.ReactNode; user: any }) {
  const router = useRouter()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const handleLogout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("user")
    router.push("/")
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <aside
        className={`${
          sidebarOpen ? "w-64" : "w-20"
        } bg-sidebar border-r border-sidebar-border transition-all duration-300 flex flex-col`}
      >
        <div className="p-4 border-b border-sidebar-border">
          <div className="flex items-center justify-between">
            {sidebarOpen && <span className="font-bold text-sidebar-foreground">FinanceAI</span>}
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="text-sidebar-foreground hover:bg-sidebar-accent rounded p-1"
            >
              {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          <NavItem icon={Home} label="Dashboard" href="/dashboard" open={sidebarOpen} />
          <NavItem icon={TrendingUp} label="Expenses" href="/expenses" open={sidebarOpen} />
          <NavItem icon={TrendingDown} label="Reduce Spending" href="/spending-reduction" open={sidebarOpen} />
          <NavItem icon={MessageCircle} label="SMS Import" href="/sms-import" open={sidebarOpen} />
          <NavItem icon={Target} label="Goals" href="/goals" open={sidebarOpen} />
          <NavItem icon={Zap} label="Budget Alerts" href="/alerts" open={sidebarOpen} />
          <NavItem icon={Settings} label="Settings" href="/settings" open={sidebarOpen} />
        </nav>

        <div className="p-4 border-t border-sidebar-border">
          <Button
            onClick={handleLogout}
            variant="ghost"
            className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent"
          >
            <LogOut className="w-5 h-5" />
            {sidebarOpen && <span className="ml-3">Logout</span>}
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <div className="p-6 md:p-8">{children}</div>
      </main>
    </div>
  )
}

function NavItem({
  icon: Icon,
  label,
  href,
  open,
}: {
  icon: any
  label: string
  href: string
  open: boolean
}) {
  return (
    <Link href={href} className="block">
      <div className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-sidebar-accent text-sidebar-foreground transition-colors">
        <Icon className="w-5 h-5 flex-shrink-0" />
        {open && <span className="text-sm">{label}</span>}
      </div>
    </Link>
  )
}
