(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_eb29c5bd._.js",
  "static/chunks/_f88995a6._.js"
],
    source: "dynamic"
});
