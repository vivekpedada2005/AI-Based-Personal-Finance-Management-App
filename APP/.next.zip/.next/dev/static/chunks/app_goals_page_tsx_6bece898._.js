(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_85ae9673._.js",
  "static/chunks/_c5c2a2ba._.js"
],
    source: "dynamic"
});
