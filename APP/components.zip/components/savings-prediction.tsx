"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"
import { predictSavings } from "@/lib/forecast-model"

export function SavingsPrediction({ user, monthlyExpenses }: { user: any; monthlyExpenses: number[] }) {
  const salary = user?.salary || 50000
  const predictions = predictSavings(salary, monthlyExpenses)

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }}>
              {entry.name}: ₹{entry.value.toLocaleString("en-IN")}
            </p>
          ))}
        </div>
      )
    }
    return null
  }

  return (
    <Card className="border-primary/20">
      <CardHeader>
        <CardTitle>3-Month Savings Forecast</CardTitle>
        <CardDescription>Predicted savings based on your spending patterns and salary</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="w-full h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={predictions} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Line
                type="monotone"
                dataKey="savings"
                stroke="var(--color-accent)"
                strokeWidth={2}
                name="Predicted Savings"
              />
              <Line
                type="monotone"
                dataKey="totalExpenses"
                stroke="var(--color-chart-4)"
                strokeWidth={2}
                name="Predicted Expenses"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="grid grid-cols-3 gap-4 mt-6">
          {predictions.map((prediction) => (
            <div key={prediction.month} className="p-3 rounded-lg bg-muted/50">
              <p className="text-xs text-muted-foreground">{prediction.month}</p>
              <p className="text-lg font-bold text-accent">₹{prediction.savings.toLocaleString("en-IN")}</p>
              <p className="text-xs text-muted-foreground">{prediction.savingsRate}% saved</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
