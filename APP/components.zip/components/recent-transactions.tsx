"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { categorizeExpense } from "@/lib/forecast-model"
import { ArrowDownRight, ArrowUpRight, Trash2 } from "lucide-react"
import { useState } from "react"

export function RecentTransactions({ transactions }: { transactions: any[] }) {
  const [txList, setTxList] = useState(transactions)

  const categorizedTransactions = txList.map((tx) => ({
    ...tx,
    category: tx.category || categorizeExpense(tx.description),
    isIncome: tx.description.toLowerCase().includes("salary") || tx.description.toLowerCase().includes("income"),
  }))

  const displayTransactions = categorizedTransactions.slice(0, 8)

  const handleDeleteTransaction = (id: string) => {
    const updated = txList.filter((tx) => tx.id !== id)
    setTxList(updated)
    const user = JSON.parse(localStorage.getItem("user") || "{}")
    const userEmail = user?.email
    if (userEmail) {
      localStorage.setItem(`transactions_${userEmail}`, JSON.stringify(updated))
    }
  }

  return (
    <Card className="border-primary/20">
      <CardHeader>
        <CardTitle>Recent Transactions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {displayTransactions.length > 0 ? (
            displayTransactions.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center justify-between py-3 border-b border-border last:border-0 hover:bg-muted/30 px-2 rounded transition-colors group"
              >
                <div className="flex items-center gap-3 flex-1">
                  <div className={`p-2 rounded-lg ${tx.isIncome ? "bg-green-100" : "bg-destructive/10"}`}>
                    {tx.isIncome ? (
                      <ArrowUpRight className="w-4 h-4 text-green-600" />
                    ) : (
                      <ArrowDownRight className="w-4 h-4 text-destructive" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-sm">{tx.description}</p>
                    <Badge variant="outline" className="text-xs mt-1">
                      {tx.category}
                    </Badge>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <p className={`font-semibold text-sm ${tx.isIncome ? "text-green-600" : "text-foreground"}`}>
                      {tx.isIncome ? "+" : "-"}₹{tx.amount.toLocaleString("en-IN", { maximumFractionDigits: 2 })}
                    </p>
                    <p className="text-xs text-muted-foreground">{new Date(tx.date).toLocaleDateString()}</p>
                  </div>
                  <button
                    onClick={() => handleDeleteTransaction(tx.id)}
                    className="opacity-0 group-hover:opacity-100 text-destructive hover:text-destructive/80 transition-opacity p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          ) : (
            <p className="text-center text-muted-foreground py-8">No transactions yet. Add one to get started!</p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
