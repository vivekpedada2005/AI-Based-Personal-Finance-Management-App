"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertCircle, MessageCircle, Check } from "lucide-react"
import { parseTransactionFromMessage, categorizeExpense } from "@/lib/forecast-model"

export default function SmsImportPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [messages, setMessages] = useState("")
  const [parsedTransactions, setParsedTransactions] = useState<any[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const token = localStorage.getItem("token")
    const userData = localStorage.getItem("user")

    if (!token || !userData) {
      router.push("/login")
      return
    }

    setUser(JSON.parse(userData))
  }, [router])

  const handleParseMessages = () => {
    if (!messages.trim()) {
      alert("Please enter at least one message")
      return
    }

    const lines = messages.split("\n").filter((line) => line.trim())
    const transactions: any[] = []

    lines.forEach((message) => {
      const parsed = parseTransactionFromMessage(message)
      if (parsed.amount && parsed.amount > 0) {
        transactions.push({
          id: Date.now().toString() + Math.random(),
          description: parsed.description || message.substring(0, 50),
          amount: parsed.amount,
          category: categorizeExpense(parsed.description || message),
          date: new Date(),
          timestamp: Date.now(),
          source: "sms",
        })
      }
    })

    setParsedTransactions(transactions)
  }

  const handleImportTransactions = () => {
    if (parsedTransactions.length === 0) {
      alert("No transactions to import")
      return
    }

    setLoading(true)

    try {
      const userEmail = user.email || "user"
      const transactionKey = `transactions_${userEmail}`
      const existingTransactions = JSON.parse(localStorage.getItem(transactionKey) || "[]")
      const allTransactions = [...existingTransactions, ...parsedTransactions]
      localStorage.setItem(transactionKey, JSON.stringify(allTransactions))

      alert(`Successfully imported ${parsedTransactions.length} transactions!`)
      setMessages("")
      setParsedTransactions([])
      router.push("/dashboard")
    } catch (error) {
      alert("Error importing transactions")
    } finally {
      setLoading(false)
    }
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6 animate-in fade-in">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Import from SMS/Messages
          </h1>
          <p className="text-muted-foreground">
            Paste your bank transaction messages to automatically extract and categorize expenses
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageCircle className="w-5 h-5" />
                  Paste Messages
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Enter Bank SMS Messages (one per line)</label>
                  <textarea
                    value={messages}
                    onChange={(e) => setMessages(e.target.value)}
                    placeholder={`Example:\nYour Bank: Amount ₹5000 debited for Online Transfer\nYour Bank: Amount ₹2500 spent on Starbucks\nYour Bank: Amount ₹1000 withdrawn from ATM`}
                    className="w-full h-48 px-4 py-3 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                  />
                  <p className="text-xs text-muted-foreground">
                    Supports: Amount in ₹, descriptions like grocery, food, gas, etc.
                  </p>
                </div>

                <Button onClick={handleParseMessages} className="w-full">
                  Parse Messages
                </Button>
              </CardContent>
            </Card>

            {parsedTransactions.length > 0 && (
              <Card className="border-green-200 bg-green-50/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-green-900">
                    <Check className="w-5 h-5" />
                    Parsed Transactions ({parsedTransactions.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {parsedTransactions.map((transaction, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                      <div className="flex-1">
                        <p className="font-medium">{transaction.description}</p>
                        <div className="flex gap-2 mt-1">
                          <span className="text-xs bg-slate-100 px-2 py-1 rounded">{transaction.category}</span>
                        </div>
                      </div>
                      <p className="font-semibold text-lg">₹{transaction.amount.toLocaleString()}</p>
                    </div>
                  ))}

                  <Button onClick={handleImportTransactions} className="w-full mt-4" disabled={loading}>
                    {loading ? "Importing..." : "Import All Transactions"}
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          <div className="space-y-4">
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="p-4">
                <h3 className="font-semibold text-blue-900 mb-3">How it works</h3>
                <ol className="text-sm text-blue-800 space-y-2">
                  <li className="flex gap-2">
                    <span className="font-bold">1.</span>
                    <span>Copy SMS messages from your bank</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-bold">2.</span>
                    <span>Paste them in the text area (one per line)</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-bold">3.</span>
                    <span>Click "Parse Messages"</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="font-bold">4.</span>
                    <span>Review and import transactions</span>
                  </li>
                </ol>
              </CardContent>
            </Card>

            <Card className="bg-yellow-50 border-yellow-200">
              <CardContent className="p-4">
                <div className="flex gap-2">
                  <AlertCircle className="w-5 h-5 text-yellow-700 flex-shrink-0" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Supported Formats</p>
                    <ul className="space-y-1 text-xs">
                      <li>• ₹5000 spent on...</li>
                      <li>• Amount ₹2500 debited</li>
                      <li>• Paid ₹1000 for...</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
