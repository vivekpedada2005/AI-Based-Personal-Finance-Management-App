export interface Transaction {
  id: string
  description: string
  amount: number
  date: Date
  category?: string
}

export interface SavingsPrediction {
  month: string
  totalIncome: number
  totalExpenses: number
  savings: number
  savingsRate: number
}

export function checkTransactionLimitWarning(amount: number, transactionLimit: number): boolean {
  return amount > transactionLimit
}

export function parseTransactionFromMessage(message: string): { amount?: number; description?: string } {
  // Parse common transaction patterns from SMS/messages
  const patterns = [
    /(?:paid|charged|debited|spent|cost|transaction|transfer|sent)\s*(?:of\s+)?₹?\s*([0-9,]+(?:\.[0-9]{2})?)/i,
    /₹\s*([0-9,]+(?:\.[0-9]{2})?)/,
    /[0-9,]+(?:\.[0-9]{2})?/,
  ]

  let amount: number | undefined
  for (const pattern of patterns) {
    const match = message.match(pattern)
    if (match) {
      amount = Number.parseFloat(match[1].replace(/,/g, ""))
      break
    }
  }

  return {
    amount,
    description: message.substring(0, 50),
  }
}

// Generate spending reduction strategies
export function generateSpendingReductionTips(categoryTotals: Map<string, number>, totalExpenses: number): string[] {
  const tips: string[] = []

  categoryTotals.forEach((amount, category) => {
    const percentage = (amount / totalExpenses) * 100

    if (category === "Food & Dining") {
      if (percentage > 30) {
        tips.push({
          category,
          percentage: Math.round(percentage),
          action: "Cook at home 4x/week instead of dining out",
          saving: Math.round(amount * 0.4),
          severity: "high",
        })
      } else if (percentage > 20) {
        tips.push({
          category,
          percentage: Math.round(percentage),
          action: "Meal prep on Sundays to reduce takeout",
          saving: Math.round(amount * 0.25),
          severity: "medium",
        })
      }
    }

    if (category === "Entertainment") {
      if (percentage > 15) {
        tips.push({
          category,
          percentage: Math.round(percentage),
          action: "Use free entertainment: parks, libraries, hiking",
          saving: Math.round(amount * 0.5),
          severity: "high",
        })
      }
    }

    if (category === "Shopping") {
      if (percentage > 15) {
        tips.push({
          category,
          percentage: Math.round(percentage),
          action: "Implement 7-day rule: wait before making purchases",
          saving: Math.round(amount * 0.35),
          severity: "high",
        })
      }
    }

    if (category === "Transport") {
      if (percentage > 15) {
        tips.push({
          category,
          percentage: Math.round(percentage),
          action: "Use public transit or carpool 3x/week",
          saving: Math.round(amount * 0.4),
          severity: "medium",
        })
      }
    }

    if (category === "Utilities") {
      if (percentage > 10) {
        tips.push({
          category,
          percentage: Math.round(percentage),
          action: "Switch to LED bulbs, unplug devices, optimize AC usage",
          saving: Math.round(amount * 0.2),
          severity: "low",
        })
      }
    }
  })

  return tips
}

// Lightweight ML forecasting model using exponential smoothing
export function predictExpenses(historicalData: number[]): number[] {
  if (historicalData.length < 2) return historicalData

  const alpha = 0.3
  const beta = 0.1
  const gamma = 0.1

  let level = historicalData[0]
  let trend = historicalData[1] - historicalData[0]
  const predictions: number[] = []

  for (let i = 1; i < historicalData.length; i++) {
    const prevLevel = level
    level = alpha * historicalData[i] + (1 - alpha) * (level + trend)
    trend = beta * (level - prevLevel) + (1 - beta) * trend
    predictions.push(Math.round(level))
  }

  for (let i = 0; i < 2; i++) {
    const nextForecast = level + trend * (i + 1)
    predictions.push(Math.round(nextForecast))
  }

  return predictions
}

export const EXPENSE_CATEGORIES = [
  "Food & Dining",
  "Transport",
  "Entertainment",
  "Utilities",
  "Shopping",
  "Health & Fitness",
  "Education",
  "Other",
]

export function categorizeExpense(description: string): string {
  const lower = description.toLowerCase()

  if (lower.includes("food") || lower.includes("restaurant") || lower.includes("grocery") || lower.includes("coffee"))
    return "Food & Dining"
  if (lower.includes("uber") || lower.includes("gas") || lower.includes("transport") || lower.includes("ride"))
    return "Transport"
  if (lower.includes("movie") || lower.includes("netflix") || lower.includes("game")) return "Entertainment"
  if (lower.includes("electric") || lower.includes("water") || lower.includes("internet") || lower.includes("bill"))
    return "Utilities"
  if (lower.includes("amazon") || lower.includes("shop") || lower.includes("store") || lower.includes("purchase"))
    return "Shopping"
  if (lower.includes("gym") || lower.includes("health") || lower.includes("doctor") || lower.includes("appointment"))
    return "Health & Fitness"
  if (lower.includes("school") || lower.includes("course") || lower.includes("book")) return "Education"

  return "Other"
}

export function generateSavingsTips(
  salary: number,
  totalExpenses: number,
  categorizedExpenses: { category: string; amount: number }[],
): string[] {
  const tips: string[] = []
  const savingsAmount = salary - totalExpenses
  const savingsRate = (savingsAmount / salary) * 100

  if (savingsRate < 10) {
    tips.push(`Your savings rate is only ${Math.round(savingsRate)}%. Target 20% to build wealth faster.`)
  } else if (savingsRate >= 20) {
    tips.push(`Excellent! You're saving ${Math.round(savingsRate)}% of your salary. Keep it up!`)
  }

  const categoryTotals = new Map<string, number>()
  categorizedExpenses.forEach((exp) => {
    categoryTotals.set(exp.category, (categoryTotals.get(exp.category) || 0) + exp.amount)
  })

  const total = Array.from(categoryTotals.values()).reduce((a, b) => a + b, 0)

  categoryTotals.forEach((amount, category) => {
    const percentage = (amount / total) * 100

    if (category === "Food & Dining" && percentage > 25) {
      tips.push(`Cook meals at home 4x/week to save ₹${Math.round(amount * 0.4)} monthly.`)
    }
    if (category === "Entertainment" && percentage > 15) {
      tips.push(`Explore free activities to reduce entertainment by ₹${Math.round(amount * 0.5)}/month.`)
    }
    if (category === "Transport" && percentage > 20) {
      tips.push(`Carpool 3x/week to save ₹${Math.round(amount * 0.4)} on transport costs.`)
    }
    if (category === "Shopping" && percentage > 20) {
      tips.push(`Use 7-day purchase rule to cut impulse buying by ₹${Math.round(amount * 0.35)}.`)
    }
  })

  if (tips.length === 0) {
    tips.push(`Your spending is well-balanced. Keep saving ${Math.round(savingsRate)}% monthly!`)
  }

  return tips
}

export function predictSavings(salary: number, monthlyExpenses: number[]): SavingsPrediction[] {
  const predictions: SavingsPrediction[] = []
  const currentDate = new Date()
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

  const predictedExpenses = predictExpenses(monthlyExpenses)

  for (let i = 0; i < 3; i++) {
    const date = new Date(currentDate)
    date.setMonth(date.getMonth() + i)
    const monthName = months[date.getMonth()]

    const expenses = predictedExpenses[Math.min(i + monthlyExpenses.length, predictedExpenses.length - 1)] || 0
    const savings = Math.max(salary - expenses, 0)
    const savingsRate = (savings / salary) * 100

    predictions.push({
      month: `${monthName} ${date.getFullYear()}`,
      totalIncome: salary,
      totalExpenses: Math.round(expenses),
      savings: Math.round(savings),
      savingsRate: Math.round(savingsRate),
    })
  }

  return predictions
}
