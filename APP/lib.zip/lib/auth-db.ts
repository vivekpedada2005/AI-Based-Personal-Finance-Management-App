const users = new Map([
  [
    "demo@example.com",
    {
      id: "1",
      email: "demo@example.com",
      name: "John Doe",
      password: "password123",
      salary: 50000,
      monthlyBudget: 40000,
      transactionLimit: 5000,
      savingsGoal: 10000,
    },
  ],
  [
    "test@example.com",
    {
      id: "2",
      email: "test@example.com",
      name: "Jane Smith",
      password: "password123",
      salary: 45000,
      monthlyBudget: 36000,
      transactionLimit: 4500,
      savingsGoal: 9000,
    },
  ],
])

export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email) && email.length <= 254
}

export function getUsers() {
  return users
}

export function getUserByEmail(email: string) {
  return users.get(email)
}

export function createUser(email: string, userData: any) {
  users.set(email, userData)
}

export function userExists(email: string) {
  return users.has(email)
}
