module.exports = [
"[project]/.next-internal/server/app/goals/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_goals_page_actions_b2368d0c.js.map