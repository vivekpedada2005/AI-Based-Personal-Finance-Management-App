"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { categorizeExpense, EXPENSE_CATEGORIES } from "@/lib/forecast-model"

export function ExpenseChart({ transactions }: { transactions: any[] }) {
  const categoryTotals = new Map<string, number>()

  transactions.forEach((tx) => {
    const category = tx.category || categorizeExpense(tx.description)
    categoryTotals.set(category, (categoryTotals.get(category) || 0) + tx.amount)
  })

  const chartData = EXPENSE_CATEGORIES.map((category) => ({
    name: category,
    spent: Math.round(categoryTotals.get(category) || 0),
    budget: Math.round((categoryTotals.get(category) || 0) * 1.2),
  }))

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }}>
              {entry.name}: ₹{entry.value.toLocaleString("en-IN")}
            </p>
          ))}
        </div>
      )
    }
    return null
  }

  return (
    <Card className="border-primary/20">
      <CardHeader>
        <CardTitle>Spending by Category</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={320}>
          <BarChart data={chartData} margin={{ top: 20, right: 30, left: 0, bottom: 60 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
            <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
            <YAxis />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Bar dataKey="spent" fill="var(--color-chart-1)" name="Actual Spending" />
            <Bar dataKey="budget" fill="var(--color-chart-2)" name="Budget" opacity={0.6} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
