"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, TrendingUp, Lightbulb, Target } from "lucide-react"

export function BudgetTips({ transactions, user, tips }: { transactions: any[]; user: any; tips: string[] }) {
  const tipIcons = [TrendingUp, AlertCircle, Lightbulb, Target]

  const displayTips = tips.slice(0, 4).map((tip, idx) => ({
    icon: tipIcons[idx % tipIcons.length],
    title: tip.split(".")[0],
    description: tip,
    type: idx === 1 ? "warning" : idx === 2 ? "suggestion" : "tip",
  }))

  return (
    <Card className="border-accent/20">
      <CardHeader>
        <CardTitle>Savings Tips</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {displayTips.length > 0 ? (
          displayTips.map((tip, index) => (
            <div
              key={index}
              className={`p-3 rounded-lg border transition-colors ${
                tip.type === "warning"
                  ? "border-destructive/30 bg-destructive/5 hover:bg-destructive/10"
                  : tip.type === "suggestion"
                    ? "border-accent/30 bg-accent/5 hover:bg-accent/10"
                    : "border-primary/30 bg-primary/5 hover:bg-primary/10"
              }`}
            >
              <div className="flex gap-3">
                <tip.icon className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-medium text-sm">{tip.title}</p>
                  <p className="text-xs text-muted-foreground line-clamp-2">{tip.description}</p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-muted-foreground py-4 text-sm">No tips yet</p>
        )}
      </CardContent>
    </Card>
  )
}
