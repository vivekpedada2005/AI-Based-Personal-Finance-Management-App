import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json()

    if (!email) {
      return NextResponse.json({ message: "Email required" }, { status: 400 })
    }

    // Simulate sending reset email
    const resetToken = Buffer.from(`${email}:${Date.now()}`).toString("base64")
    const resetLink = `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/reset-password?token=${resetToken}`

    console.log(`[Password Reset] Sent reset link to ${email}: ${resetLink}`)

    return NextResponse.json({
      message: "Password reset link sent to your email",
      token: resetToken,
    })
  } catch (error) {
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}
