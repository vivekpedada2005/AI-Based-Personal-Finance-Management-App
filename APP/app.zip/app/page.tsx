"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, TrendingUp, BarChart3, Target } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
      {/* Navigation */}
      <nav className="flex items-center justify-between px-6 py-4 border-b border-border">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary text-primary-foreground flex items-center justify-center font-bold">
            F
          </div>
          <span className="font-semibold text-lg">FinanceAI</span>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/login">
            <Button variant="ghost">Sign In</Button>
          </Link>
          <Link href="/signup">
            <Button>Get Started</Button>
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="px-6 py-24 text-center max-w-4xl mx-auto">
        <h1 className="text-5xl font-bold mb-6 text-foreground">Smarter Finance, Better Future</h1>
        <p className="text-xl text-muted-foreground mb-8">
          Track your spending, predict your future, and save more with AI-powered insights. Take control of your money
          today.
        </p>
        <Link href="/signup">
          <Button size="lg" className="gap-2">
            Start Free <ArrowRight className="w-4 h-4" />
          </Button>
        </Link>
      </section>

      {/* Features Section */}
      <section className="px-6 py-16 max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="p-8 rounded-xl bg-card border border-border">
          <TrendingUp className="w-12 h-12 text-primary mb-4" />
          <h3 className="font-semibold text-lg mb-2">Real-time Tracking</h3>
          <p className="text-muted-foreground">Monitor your expenses as they happen with automatic categorization</p>
        </div>
        <div className="p-8 rounded-xl bg-card border border-border">
          <BarChart3 className="w-12 h-12 text-primary mb-4" />
          <h3 className="font-semibold text-lg mb-2">AI Forecasting</h3>
          <p className="text-muted-foreground">Predict future expenses with machine learning accuracy</p>
        </div>
        <div className="p-8 rounded-xl bg-card border border-border">
          <Target className="w-12 h-12 text-primary mb-4" />
          <h3 className="font-semibold text-lg mb-2">Savings Goals</h3>
          <p className="text-muted-foreground">Set and track goals with personalized recommendations</p>
        </div>
      </section>
    </div>
  )
}
