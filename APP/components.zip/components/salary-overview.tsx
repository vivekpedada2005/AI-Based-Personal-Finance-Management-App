"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, Target, DollarSign } from "lucide-react"

export function SalaryOverview({ user, transactions }: { user: any; transactions: any[] }) {
  const salary = user?.salary || 50000
  const savingsGoal = user?.savingsGoal || salary * 0.2

  const totalExpenses = transactions.reduce((sum, t) => sum + t.amount, 0)
  const currentSavings = salary - totalExpenses
  const goalProgress = (currentSavings / savingsGoal) * 100

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Card className="border-primary/20 bg-gradient-to-br from-card to-card/80">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-primary" />
            Monthly Salary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-foreground">₹{salary.toLocaleString("en-IN")}</div>
          <p className="text-xs text-muted-foreground mt-1">Gross monthly income</p>
        </CardContent>
      </Card>

      <Card className="border-accent/20 bg-gradient-to-br from-card to-card/80">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-accent" />
            Current Savings
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-foreground">₹{currentSavings.toLocaleString("en-IN")}</div>
          <p className="text-xs text-muted-foreground mt-1">
            {((currentSavings / salary) * 100).toFixed(1)}% of salary
          </p>
        </CardContent>
      </Card>

      <Card className="border-green-200/30 bg-gradient-to-br from-card to-card/80">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Target className="w-4 h-4 text-green-600" />
            Goal Progress
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-foreground">₹{Math.round(savingsGoal).toLocaleString("en-IN")}</div>
          <div className="w-full bg-muted rounded-full h-2 mt-3">
            <div
              className="bg-gradient-to-r from-primary to-accent h-2 rounded-full transition-all"
              style={{ width: `${Math.min(goalProgress, 100)}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-2">{Math.round(goalProgress)}% of monthly goal</p>
        </CardContent>
      </Card>
    </div>
  )
}
