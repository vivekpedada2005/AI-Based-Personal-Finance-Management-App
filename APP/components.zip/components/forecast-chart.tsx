"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { predictExpenses } from "@/lib/forecast-model"

export function ForecastChart({ transactions }: { transactions: any[] }) {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
  const today = new Date()

  const totalExpenses = transactions.reduce((sum, t) => sum + t.amount, 0)
  const averageExpense = transactions.length > 0 ? totalExpenses / Math.min(transactions.length, 30) : 0

  // Create historical data from actual transactions
  const historicalData = Array(6)
    .fill(0)
    .map((_, i) => {
      const monthStart = new Date(today.getFullYear(), today.getMonth() - i, 1)
      const monthEnd = new Date(today.getFullYear(), today.getMonth() - i + 1, 0)

      const monthTotal = transactions
        .filter((tx) => {
          const txDate = new Date(tx.date)
          return txDate >= monthStart && txDate <= monthEnd
        })
        .reduce((sum, tx) => sum + tx.amount, 0)

      return monthTotal || Math.round(averageExpense * 20)
    })
    .reverse()

  const predictions = predictExpenses(historicalData)

  const forecastData = months.map((month, idx) => {
    const isHistorical = idx < 6
    return {
      month,
      actual: isHistorical ? historicalData[idx] : null,
      predicted: predictions[idx],
    }
  })

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          {payload.map(
            (entry: any, index: number) =>
              entry.value && (
                <p key={index} style={{ color: entry.color }}>
                  {entry.name}: ₹{entry.value.toLocaleString("en-IN")}
                </p>
              ),
          )}
        </div>
      )
    }
    return null
  }

  return (
    <Card className="border-primary/20">
      <CardHeader>
        <CardTitle>6-Month Expense Forecast</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={forecastData}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Line type="monotone" dataKey="actual" stroke="var(--color-chart-1)" name="Historical" strokeWidth={2} />
            <Line
              type="monotone"
              dataKey="predicted"
              stroke="var(--color-chart-3)"
              strokeDasharray="5 5"
              name="Forecasted"
              strokeWidth={2}
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
