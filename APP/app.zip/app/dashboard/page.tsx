"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { ExpenseSummary } from "@/components/expense-summary"
import { ExpenseChart } from "@/components/expense-chart"
import { RecentTransactions } from "@/components/recent-transactions"
import { BudgetTips } from "@/components/budget-tips"
import { ForecastChart } from "@/components/forecast-chart"
import { SalaryOverview } from "@/components/salary-overview"
import { SavingsPrediction } from "@/components/savings-prediction"
import { AddTransaction } from "@/components/add-transaction"
import { generateSavingsTips, categorizeExpense } from "@/lib/forecast-model"

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [transactions, setTransactions] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem("token")
    const userData = localStorage.getItem("user")

    if (!token || !userData) {
      router.push("/login")
      return
    }

    const parsedUser = JSON.parse(userData)
    setUser(parsedUser)
    loadTransactions()
  }, [router])

  const loadTransactions = () => {
    const userData = JSON.parse(localStorage.getItem("user") || "{}")
    const userEmail = userData.email || "user"
    const transactionKey = `transactions_${userEmail}`
    const savedTransactions = JSON.parse(localStorage.getItem(transactionKey) || "[]")
    setTransactions(savedTransactions)
    setLoading(false)
  }

  const handleTransactionAdded = (newTransaction: any) => {
    setTransactions((prev) => [newTransaction, ...prev])
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-muted-foreground">Loading your financial data...</div>
      </div>
    )
  }

  const totalExpenses = transactions.reduce((sum, t) => sum + t.amount, 0)
  const monthlyExpenses = [totalExpenses * 0.9, totalExpenses * 0.95, totalExpenses]

  const categorizedExpenses = transactions.map((t) => ({
    category: t.category || categorizeExpense(t.description),
    amount: t.amount,
  }))

  const savingsTips = generateSavingsTips(user.salary, totalExpenses, categorizedExpenses)

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6 animate-in fade-in">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Welcome back, {user?.name}
          </h1>
          <p className="text-muted-foreground">Your personalized financial dashboard and savings insights</p>
        </div>

        <AddTransaction onTransactionAdded={handleTransactionAdded} />

        <SalaryOverview user={user} transactions={transactions} />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <ExpenseSummary user={user} transactions={transactions} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <ExpenseChart transactions={transactions} />
          </div>
          <BudgetTips transactions={transactions} user={user} tips={savingsTips} />
        </div>

        <SavingsPrediction user={user} monthlyExpenses={monthlyExpenses} />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ForecastChart transactions={transactions} />
          <RecentTransactions transactions={transactions} />
        </div>
      </div>
    </DashboardLayout>
  )
}
