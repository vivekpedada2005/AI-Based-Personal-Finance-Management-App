"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent } from "@/components/ui/card"
import { AlertCircle, TrendingDown, PiggyBank, Zap } from "lucide-react"
import { generateSpendingReductionTips, categorizeExpense } from "@/lib/forecast-model"

export default function SpendingReductionPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [transactions, setTransactions] = useState<any[]>([])
  const [tips, setTips] = useState<any[]>([])

  useEffect(() => {
    const token = localStorage.getItem("token")
    const userData = localStorage.getItem("user")

    if (!token || !userData) {
      router.push("/login")
      return
    }

    const parsedUser = JSON.parse(userData)
    setUser(parsedUser)

    const userEmail = parsedUser.email || "user"
    const transactionKey = `transactions_${userEmail}`
    const savedTransactions = JSON.parse(localStorage.getItem(transactionKey) || "[]")
    setTransactions(savedTransactions)

    if (savedTransactions.length > 0) {
      const categoryTotals = new Map<string, number>()
      savedTransactions.forEach((t: any) => {
        const cat = t.category || categorizeExpense(t.description)
        categoryTotals.set(cat, (categoryTotals.get(cat) || 0) + t.amount)
      })

      const total = Array.from(categoryTotals.values()).reduce((a, b) => a + b, 0)
      const generatedTips = generateSpendingReductionTips(categoryTotals, total)
      setTips(generatedTips)
    }
  }, [router])

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  const totalExpenses = transactions.reduce((sum, t) => sum + t.amount, 0)
  const potentialSavings = tips.reduce((sum: number, tip: any) => sum + (tip.saving || 0), 0)

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6 animate-in fade-in">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Spending Reduction Guide
          </h1>
          <p className="text-muted-foreground">
            Personalized strategies to cut expenses and increase your monthly savings
          </p>
        </div>

        {potentialSavings > 0 && (
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
                  <PiggyBank className="w-8 h-8 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-green-700 font-medium">Potential Monthly Savings</p>
                  <p className="text-4xl font-bold text-green-900">₹{potentialSavings.toLocaleString()}</p>
                  <p className="text-sm text-green-600 mt-1">
                    By following these recommendations, you could save this amount monthly
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Spending</p>
                  <p className="text-2xl font-bold">₹{totalExpenses.toLocaleString()}</p>
                </div>
                <TrendingDown className="w-8 h-8 text-slate-300" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Potential Savings</p>
                  <p className="text-2xl font-bold text-green-600">₹{potentialSavings.toLocaleString()}</p>
                </div>
                <PiggyBank className="w-8 h-8 text-green-300" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">New Spending Level</p>
                  <p className="text-2xl font-bold text-blue-600">
                    ₹{(totalExpenses - potentialSavings).toLocaleString()}
                  </p>
                </div>
                <Zap className="w-8 h-8 text-blue-300" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <h2 className="text-2xl font-bold">Reduction Strategies</h2>
          {tips.length > 0 ? (
            tips.map((tip: any, idx: number) => (
              <Card
                key={idx}
                className={`border-l-4 ${
                  tip.severity === "high"
                    ? "border-l-red-500 bg-red-50/50"
                    : tip.severity === "medium"
                      ? "border-l-yellow-500 bg-yellow-50/50"
                      : "border-l-blue-500 bg-blue-50/50"
                }`}
              >
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div
                      className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${
                        tip.severity === "high"
                          ? "bg-red-100"
                          : tip.severity === "medium"
                            ? "bg-yellow-100"
                            : "bg-blue-100"
                      }`}
                    >
                      <AlertCircle
                        className={`w-6 h-6 ${
                          tip.severity === "high"
                            ? "text-red-600"
                            : tip.severity === "medium"
                              ? "text-yellow-600"
                              : "text-blue-600"
                        }`}
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-semibold text-lg">{tip.category}</h3>
                          <p className="text-sm text-muted-foreground">{tip.percentage}% of your total spending</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-green-600 font-semibold">Save ₹{tip.saving.toLocaleString()}</p>
                          <p className="text-xs text-muted-foreground">monthly</p>
                        </div>
                      </div>
                      <p className="text-base font-medium mb-2">{tip.action}</p>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${
                            tip.severity === "high"
                              ? "bg-red-500"
                              : tip.severity === "medium"
                                ? "bg-yellow-500"
                                : "bg-blue-500"
                          }`}
                          style={{ width: `${tip.percentage}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="p-6 text-center">
                <p className="text-slate-600">Add transactions to get personalized spending reduction tips</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </DashboardLayout>
  )
}
