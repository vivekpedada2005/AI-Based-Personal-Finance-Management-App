"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { AlertCircle, TrendingUp, Zap, Target } from "lucide-react"

export default function SignupPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    salary: "",
    monthlyBudget: "",
    transactionLimit: "",
  })
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (step === 1) {
      if (!formData.name.trim() || !formData.email.trim()) {
        setError("Please fill in all fields")
        return
      }
      setStep(2)
    } else if (step === 2) {
      if (formData.password !== formData.confirmPassword) {
        setError("Passwords do not match")
        return
      }
      if (formData.password.length < 6) {
        setError("Password must be at least 6 characters")
        return
      }
      setStep(3)
    }
  }

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!formData.salary || Number.parseFloat(formData.salary) <= 0) {
      setError("Please enter a valid monthly salary")
      return
    }

    if (!formData.monthlyBudget || Number.parseFloat(formData.monthlyBudget) <= 0) {
      setError("Please enter a valid monthly budget")
      return
    }

    if (!formData.transactionLimit || Number.parseFloat(formData.transactionLimit) <= 0) {
      setError("Please enter a valid transaction limit")
      return
    }

    setLoading(true)

    try {
      const response = await fetch("/api/auth/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          password: formData.password,
          salary: Number.parseFloat(formData.salary),
          monthlyBudget: Number.parseFloat(formData.monthlyBudget),
          transactionLimit: Number.parseFloat(formData.transactionLimit),
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        setError(data.message || "Signup failed")
        return
      }

      localStorage.setItem("token", data.token)
      localStorage.setItem("user", JSON.stringify(data.user))
      router.push("/dashboard")
    } catch (err) {
      setError("An error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-primary/5 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          {/* Left Side - Info */}
          <div className="hidden md:block space-y-8">
            <div>
              <h1 className="text-4xl font-bold text-white mb-3">Join FinanceAI</h1>
              <p className="text-lg text-slate-400">Take control of your finances with AI-powered insights</p>
            </div>

            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <TrendingUp className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-white mb-1">Real-time Tracking</h3>
                  <p className="text-sm text-slate-400">Monitor all transactions instantly</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-white mb-1">Smart Alerts</h3>
                  <p className="text-sm text-slate-400">Get notified before exceeding limits</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <Target className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-white mb-1">Smart Goals</h3>
                  <p className="text-sm text-slate-400">Achieve savings targets efficiently</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Side - Form */}
          <Card className="bg-white/95 backdrop-blur border-primary/20 shadow-2xl">
            <CardContent className="p-8">
              <div className="mb-6">
                <div className="flex gap-2 mb-4">
                  {[1, 2, 3].map((s) => (
                    <div
                      key={s}
                      className={`h-2 flex-1 rounded-full transition-all ${step >= s ? "bg-primary" : "bg-slate-200"}`}
                    />
                  ))}
                </div>
                <p className="text-sm text-slate-600">Step {step} of 3</p>
              </div>

              <form onSubmit={step === 3 ? handleSignup : handleNextStep} className="space-y-4">
                {error && (
                  <div className="flex gap-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                    <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-red-600">{error}</p>
                  </div>
                )}

                {step === 1 && (
                  <div className="space-y-4 animate-in fade-in">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Full Name</label>
                      <Input
                        placeholder="John Doe"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="h-11 rounded-lg"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Email Address</label>
                      <Input
                        type="email"
                        placeholder="you@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="h-11 rounded-lg"
                      />
                    </div>
                  </div>
                )}

                {step === 2 && (
                  <div className="space-y-4 animate-in fade-in">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Password</label>
                      <Input
                        type="password"
                        placeholder="••••••••"
                        value={formData.password}
                        onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                        className="h-11 rounded-lg"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Confirm Password</label>
                      <Input
                        type="password"
                        placeholder="••••••••"
                        value={formData.confirmPassword}
                        onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                        className="h-11 rounded-lg"
                      />
                    </div>
                  </div>
                )}

                {step === 3 && (
                  <div className="space-y-4 animate-in fade-in">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Monthly Salary (₹)</label>
                      <Input
                        type="number"
                        placeholder="50000"
                        value={formData.salary}
                        onChange={(e) => setFormData({ ...formData, salary: e.target.value })}
                        className="h-11 rounded-lg"
                        min="0"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Monthly Budget (₹)</label>
                      <Input
                        type="number"
                        placeholder="40000"
                        value={formData.monthlyBudget}
                        onChange={(e) => setFormData({ ...formData, monthlyBudget: e.target.value })}
                        className="h-11 rounded-lg"
                        min="0"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700">Transaction Warning Limit (₹)</label>
                      <Input
                        type="number"
                        placeholder="5000"
                        value={formData.transactionLimit}
                        onChange={(e) => setFormData({ ...formData, transactionLimit: e.target.value })}
                        className="h-11 rounded-lg"
                        min="0"
                      />
                      <p className="text-xs text-slate-500">You'll get an alert if single transaction exceeds this</p>
                    </div>
                  </div>
                )}

                <div className="flex gap-3 pt-4">
                  {step > 1 && (
                    <Button type="button" variant="outline" onClick={() => setStep(step - 1)} className="flex-1 h-11">
                      Back
                    </Button>
                  )}
                  <Button type="submit" className="flex-1 h-11" disabled={loading}>
                    {loading ? "Creating..." : step === 3 ? "Create Account" : "Next"}
                  </Button>
                </div>
              </form>

              <p className="text-center text-sm text-slate-600 mt-4">
                Already have an account?{" "}
                <Link href="/login" className="text-primary hover:underline font-semibold">
                  Sign in
                </Link>
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
