"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, X, AlertTriangle } from "lucide-react"
import { EXPENSE_CATEGORIES } from "@/lib/forecast-model"
import { checkTransactionLimitWarning } from "@/lib/forecast-model"

export function AddTransaction({ onTransactionAdded }: { onTransactionAdded: (transaction: any) => void }) {
  const [isOpen, setIsOpen] = useState(false)
  const [description, setDescription] = useState("")
  const [amount, setAmount] = useState("")
  const [category, setCategory] = useState("Other")
  const [date, setDate] = useState(new Date().toISOString().split("T")[0])
  const [limitWarning, setLimitWarning] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!description.trim() || !amount.trim()) {
      alert("Please fill in all fields")
      return
    }

    const user = JSON.parse(localStorage.getItem("user") || "{}")
    const transactionAmount = Number.parseFloat(amount)
    const limit = user.transactionLimit || 5000

    if (checkTransactionLimitWarning(transactionAmount, limit)) {
      setLimitWarning(true)
      return
    }

    const newTransaction = {
      id: Date.now().toString(),
      description: description.trim(),
      amount: transactionAmount,
      category,
      date: new Date(date),
      timestamp: Date.now(),
    }

    const userEmail = user.email || "user"
    const transactionKey = `transactions_${userEmail}`
    const existingTransactions = JSON.parse(localStorage.getItem(transactionKey) || "[]")
    existingTransactions.push(newTransaction)
    localStorage.setItem(transactionKey, JSON.stringify(existingTransactions))

    onTransactionAdded(newTransaction)

    setDescription("")
    setAmount("")
    setCategory("Other")
    setDate(new Date().toISOString().split("T")[0])
    setLimitWarning(false)
    setIsOpen(false)
  }

  return (
    <>
      {!isOpen ? (
        <Button onClick={() => setIsOpen(true)} className="w-full md:w-auto gap-2">
          <Plus className="w-4 h-4" />
          Add Transaction
        </Button>
      ) : (
        <Card className="border-primary/20">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
            <CardTitle className="text-lg">Add New Transaction</CardTitle>
            <button onClick={() => setIsOpen(false)} className="text-muted-foreground hover:text-foreground">
              <X className="w-5 h-5" />
            </button>
          </CardHeader>
          <CardContent>
            {limitWarning && (
              <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex gap-3">
                <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-red-900">Transaction Limit Exceeded</p>
                  <p className="text-sm text-red-700">
                    This transaction exceeds your ₹
                    {(JSON.parse(localStorage.getItem("user") || "{}").transactionLimit || 5000).toLocaleString()}{" "}
                    limit.
                  </p>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setLimitWarning(false)}
                    className="mt-2 text-red-600 hover:text-red-700"
                  >
                    Proceed Anyway
                  </Button>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Description</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g., Coffee, Groceries, Gas"
                  className="w-full px-3 py-2 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Amount (₹)</label>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    step="0.01"
                    min="0"
                    className="w-full px-3 py-2 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Date</label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  {EXPENSE_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <Button type="submit" className="flex-1">
                  Add Transaction
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsOpen(false)} className="flex-1">
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}
    </>
  )
}
