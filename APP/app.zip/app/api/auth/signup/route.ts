import { type NextRequest, NextResponse } from "next/server"
import { userExists, createUser, isValidEmail } from "@/lib/auth-db"

export async function POST(request: NextRequest) {
  try {
    const { name, email, password, salary, monthlyBudget, transactionLimit } = await request.json()

    if (!name || !email || !password || !salary) {
      return NextResponse.json({ message: "All fields are required" }, { status: 400 })
    }

    if (!isValidEmail(email)) {
      return NextResponse.json({ message: "Please enter a valid email address" }, { status: 400 })
    }

    if (password.length < 6) {
      return NextResponse.json({ message: "Password must be at least 6 characters" }, { status: 400 })
    }

    if (salary <= 0) {
      return NextResponse.json({ message: "Salary must be greater than 0" }, { status: 400 })
    }

    if (userExists(email)) {
      return NextResponse.json(
        { message: "This email is already registered. Please use a different email or login." },
        { status: 400 },
      )
    }

    const userId = Date.now().toString()
    const newUser = {
      id: userId,
      name,
      email,
      password,
      salary: Number.parseFloat(salary),
      monthlyBudget: Number.parseFloat(monthlyBudget) || salary * 0.8,
      transactionLimit: Number.parseFloat(transactionLimit) || 5000,
      savingsGoal: salary * 0.2,
    }
    createUser(email, newUser)

    const token = Buffer.from(`${email}:${Date.now()}`).toString("base64")

    return NextResponse.json(
      {
        token,
        user: {
          id: userId,
          email,
          name,
          salary: newUser.salary,
          monthlyBudget: newUser.monthlyBudget,
          transactionLimit: newUser.transactionLimit,
          savingsGoal: newUser.savingsGoal,
        },
      },
      { status: 201 },
    )
  } catch (error) {
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}
