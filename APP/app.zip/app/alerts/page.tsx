"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, Bell, CheckCircle2 } from "lucide-react"

export default function AlertsPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [transactions, setTransactions] = useState<any[]>([])
  const [alerts, setAlerts] = useState<any[]>([])

  useEffect(() => {
    const token = localStorage.getItem("token")
    const userData = localStorage.getItem("user")

    if (!token || !userData) {
      router.push("/login")
      return
    }

    const parsedUser = JSON.parse(userData)
    setUser(parsedUser)

    const userEmail = parsedUser.email || "user"
    const transactionKey = `transactions_${userEmail}`
    const savedTransactions = JSON.parse(localStorage.getItem(transactionKey) || "[]")
    setTransactions(savedTransactions)

    const generatedAlerts: any[] = []
    let totalExpenses = 0
    const highTransactions: any[] = []

    savedTransactions.forEach((t: any) => {
      totalExpenses += t.amount

      if (t.amount > (parsedUser.transactionLimit || 5000)) {
        highTransactions.push(t)
      }
    })

    if (totalExpenses > (parsedUser.monthlyBudget || 40000)) {
      generatedAlerts.push({
        type: "budget",
        severity: "high",
        title: "Monthly Budget Exceeded",
        description: `You've spent ₹${totalExpenses.toLocaleString()} against a budget of ₹${parsedUser.monthlyBudget.toLocaleString()}`,
        amount: totalExpenses - parsedUser.monthlyBudget,
        timestamp: new Date(),
      })
    }

    highTransactions.forEach((t: any) => {
      generatedAlerts.push({
        type: "transaction",
        severity: "medium",
        title: "Large Transaction Detected",
        description: `Transaction of ₹${t.amount.toLocaleString()} for "${t.description}" exceeds your ₹${parsedUser.transactionLimit.toLocaleString()} limit`,
        amount: t.amount,
        timestamp: t.date,
      })
    })

    const savingsRate = ((parsedUser.salary - totalExpenses) / parsedUser.salary) * 100
    if (savingsRate < 10) {
      generatedAlerts.push({
        type: "savings",
        severity: "high",
        title: "Low Savings Rate",
        description: `Your savings rate is only ${savingsRate.toFixed(1)}%. Target at least 20% for financial security.`,
        amount: parsedUser.salary * 0.2 - (parsedUser.salary - totalExpenses),
        timestamp: new Date(),
      })
    }

    const categoryTotals = new Map<string, number>()
    savedTransactions.forEach((t: any) => {
      categoryTotals.set(t.category, (categoryTotals.get(t.category) || 0) + t.amount)
    })

    categoryTotals.forEach((amount, category) => {
      const percentage = (amount / totalExpenses) * 100
      if (percentage > 35) {
        generatedAlerts.push({
          type: "category",
          severity: "medium",
          title: `High Spending in ${category}`,
          description: `${category} accounts for ${percentage.toFixed(1)}% of your total expenses. Consider reducing.`,
          amount,
          timestamp: new Date(),
        })
      }
    })

    setAlerts(generatedAlerts.sort((a, b) => b.timestamp - a.timestamp))
  }, [router])

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  const highAlerts = alerts.filter((a) => a.severity === "high")
  const mediumAlerts = alerts.filter((a) => a.severity === "medium")

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6 animate-in fade-in">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Budget Alerts
          </h1>
          <p className="text-muted-foreground">Real-time notifications about your spending and budget status</p>
        </div>

        {alerts.length === 0 ? (
          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-8 text-center">
              <CheckCircle2 className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <p className="text-lg font-semibold text-green-900">All Clear!</p>
              <p className="text-green-700 mt-2">No budget alerts at the moment. Keep up the good spending habits!</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {highAlerts.length > 0 && (
              <div className="space-y-3">
                <h2 className="text-lg font-semibold text-red-900">Critical Alerts</h2>
                {highAlerts.map((alert, idx) => (
                  <Card key={idx} className="border-l-4 border-l-red-500 bg-red-50/50">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
                        <div className="flex-1">
                          <h3 className="font-semibold text-red-900">{alert.title}</h3>
                          <p className="text-sm text-red-700 mt-1">{alert.description}</p>
                          <p className="text-xs text-red-600 mt-2">
                            {alert.timestamp instanceof Date
                              ? alert.timestamp.toLocaleDateString()
                              : new Date(alert.timestamp).toLocaleDateString()}
                          </p>
                        </div>
                        {alert.amount && <p className="font-bold text-red-600">₹{alert.amount.toLocaleString()}</p>}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {mediumAlerts.length > 0 && (
              <div className="space-y-3">
                <h2 className="text-lg font-semibold text-yellow-900">Warnings</h2>
                {mediumAlerts.map((alert, idx) => (
                  <Card key={idx} className="border-l-4 border-l-yellow-500 bg-yellow-50/50">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <Bell className="w-6 h-6 text-yellow-600 flex-shrink-0 mt-1" />
                        <div className="flex-1">
                          <h3 className="font-semibold text-yellow-900">{alert.title}</h3>
                          <p className="text-sm text-yellow-700 mt-1">{alert.description}</p>
                          <p className="text-xs text-yellow-600 mt-2">
                            {alert.timestamp instanceof Date
                              ? alert.timestamp.toLocaleDateString()
                              : new Date(alert.timestamp).toLocaleDateString()}
                          </p>
                        </div>
                        {alert.amount && <p className="font-bold text-yellow-600">₹{alert.amount.toLocaleString()}</p>}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-900">Alert Categories</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3 bg-white rounded border">
                <p className="font-medium text-sm">Budget Threshold</p>
                <p className="text-xs text-muted-foreground mt-1">₹{user.monthlyBudget?.toLocaleString()}</p>
              </div>
              <div className="p-3 bg-white rounded border">
                <p className="font-medium text-sm">Transaction Limit</p>
                <p className="text-xs text-muted-foreground mt-1">₹{user.transactionLimit?.toLocaleString()}</p>
              </div>
              <div className="p-3 bg-white rounded border">
                <p className="font-medium text-sm">Target Savings Rate</p>
                <p className="text-xs text-muted-foreground mt-1">20% of monthly salary</p>
              </div>
              <div className="p-3 bg-white rounded border">
                <p className="font-medium text-sm">Category Alert</p>
                <p className="text-xs text-muted-foreground mt-1">When exceeding 35% of budget</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
