(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_a329371d._.js",
  "static/chunks/node_modules_recharts_es6_843264e6._.js",
  "static/chunks/node_modules_8a271ced._.js"
],
    source: "dynamic"
});
