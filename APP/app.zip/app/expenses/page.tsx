"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"

export default function ExpensesPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [transactions, setTransactions] = useState<any[]>([])
  const [chartData, setChartData] = useState<any[]>([])

  useEffect(() => {
    const token = localStorage.getItem("token")
    const userData = localStorage.getItem("user")

    if (!token || !userData) {
      router.push("/login")
      return
    }

    setUser(JSON.parse(userData))

    const userEmail = JSON.parse(userData).email || "user"
    const transactionKey = `transactions_${userEmail}`
    const savedTransactions = JSON.parse(localStorage.getItem(transactionKey) || "[]")
    setTransactions(savedTransactions)

    // Prepare category data for charts
    const categoryTotals = new Map<string, number>()
    savedTransactions.forEach((t: any) => {
      categoryTotals.set(t.category, (categoryTotals.get(t.category) || 0) + t.amount)
    })

    const data = Array.from(categoryTotals).map(([category, amount]) => ({
      category,
      amount,
    }))

    setChartData(data)
  }, [router])

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  const totalExpenses = transactions.reduce((sum, t) => sum + t.amount, 0)
  const averageTransaction = transactions.length > 0 ? totalExpenses / transactions.length : 0

  const COLORS = ["#0ea5e9", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899", "#14b8a6", "#f97316"]

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6 animate-in fade-in">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Expense Analytics
          </h1>
          <p className="text-muted-foreground">Detailed breakdown of your spending patterns</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-6">
              <p className="text-sm text-muted-foreground">Total Expenses</p>
              <p className="text-3xl font-bold mt-2">₹{totalExpenses.toLocaleString()}</p>
              <p className="text-xs text-slate-500 mt-2">{transactions.length} transactions</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <p className="text-sm text-muted-foreground">Average Transaction</p>
              <p className="text-3xl font-bold mt-2">₹{averageTransaction.toLocaleString()}</p>
              <p className="text-xs text-slate-500 mt-2">per transaction</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <p className="text-sm text-muted-foreground">Budget Status</p>
              <p className="text-3xl font-bold mt-2">
                {totalExpenses > user.monthlyBudget ? (
                  <span className="text-red-600">Over ₹{(totalExpenses - user.monthlyBudget).toLocaleString()}</span>
                ) : (
                  <span className="text-green-600">₹{(user.monthlyBudget - totalExpenses).toLocaleString()} left</span>
                )}
              </p>
              <p className="text-xs text-slate-500 mt-2">of ₹{user.monthlyBudget.toLocaleString()}</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Spending by Category</CardTitle>
            </CardHeader>
            <CardContent>
              {chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="category" angle={-45} textAnchor="end" height={100} />
                    <YAxis />
                    <Tooltip formatter={(value) => `₹${value.toLocaleString()}`} />
                    <Bar dataKey="amount" fill="#0ea5e9" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <p className="text-center text-slate-500 py-8">No expense data available</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              {chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={chartData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ category, amount }) => `${category}: ₹${amount.toLocaleString()}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="amount"
                    >
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `₹${value.toLocaleString()}`} />
                  </PieChart>
                </ResponsiveContainer>
              ) : (
                <p className="text-center text-slate-500 py-8">No expense data available</p>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Category Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {chartData.length > 0 ? (
                chartData.map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-4 h-4 rounded" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                      <span className="font-medium">{item.category}</span>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">₹{item.amount.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">
                        {((item.amount / totalExpenses) * 100).toFixed(1)}%
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-center text-slate-500 py-8">No expense data available</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
