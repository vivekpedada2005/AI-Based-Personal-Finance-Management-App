import { type NextRequest, NextResponse } from "next/server"
import { getUserByEmail, isValidEmail } from "@/lib/auth-db"

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json({ message: "Email and password are required" }, { status: 400 })
    }

    if (!isValidEmail(email)) {
      return NextResponse.json({ message: "Please enter a valid email address" }, { status: 400 })
    }

    const storedUser = await getUserByEmail(email)

    if (!storedUser) {
      return NextResponse.json(
        { message: "Email not found. Please check your email or create an account." },
        { status: 401 },
      )
    }

    if (storedUser.password !== password) {
      return NextResponse.json({ message: "Incorrect password. Please try again." }, { status: 401 })
    }

    const token = Buffer.from(`${email}:${Date.now()}`).toString("base64")

    return NextResponse.json({
      token,
      user: {
        id: storedUser.id,
        email: storedUser.email,
        name: storedUser.name,
        salary: storedUser.salary,
        monthlyBudget: storedUser.monthlyBudget,
        transactionLimit: storedUser.transactionLimit,
        savingsGoal: storedUser.savingsGoal,
      },
    })
  } catch (error) {
    return NextResponse.json({ message: "Internal server error" }, { status: 500 })
  }
}
