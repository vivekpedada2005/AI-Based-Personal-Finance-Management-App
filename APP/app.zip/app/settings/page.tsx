"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertCircle, CheckCircle2 } from "lucide-react"

export default function SettingsPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [formData, setFormData] = useState({
    salary: 0,
    monthlyBudget: 0,
    transactionLimit: 0,
  })
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    const token = localStorage.getItem("token")
    const userData = localStorage.getItem("user")

    if (!token || !userData) {
      router.push("/login")
      return
    }

    const parsedUser = JSON.parse(userData)
    setUser(parsedUser)
    setFormData({
      salary: parsedUser.salary,
      monthlyBudget: parsedUser.monthlyBudget,
      transactionLimit: parsedUser.transactionLimit,
    })
  }, [router])

  const handleSaveSettings = () => {
    if (!formData.salary || !formData.monthlyBudget || !formData.transactionLimit) {
      alert("Please fill in all fields")
      return
    }

    const updatedUser = {
      ...user,
      salary: Number.parseFloat(formData.salary.toString()),
      monthlyBudget: Number.parseFloat(formData.monthlyBudget.toString()),
      transactionLimit: Number.parseFloat(formData.transactionLimit.toString()),
    }

    localStorage.setItem("user", JSON.stringify(updatedUser))
    setUser(updatedUser)
    setSaved(true)

    setTimeout(() => setSaved(false), 3000)
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6 animate-in fade-in">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Settings
          </h1>
          <p className="text-muted-foreground">Manage your financial preferences and limits</p>
        </div>

        {saved && (
          <div className="flex gap-3 p-4 bg-green-50 border border-green-200 rounded-lg animate-in">
            <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-green-600">Settings saved successfully!</p>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-sm text-muted-foreground">Name</p>
                  <p className="font-semibold text-lg">{user.name}</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-lg">
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-semibold text-lg">{user.email}</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle>Financial Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Monthly Salary (₹)</label>
                  <input
                    type="number"
                    value={formData.salary}
                    onChange={(e) => setFormData({ ...formData, salary: Number.parseFloat(e.target.value) })}
                    className="w-full px-4 py-2 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    min="0"
                  />
                  <p className="text-xs text-muted-foreground">Your total monthly income</p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Monthly Budget (₹)</label>
                  <input
                    type="number"
                    value={formData.monthlyBudget}
                    onChange={(e) => setFormData({ ...formData, monthlyBudget: Number.parseFloat(e.target.value) })}
                    className="w-full px-4 py-2 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    min="0"
                  />
                  <p className="text-xs text-muted-foreground">Maximum spending limit per month</p>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Single Transaction Limit (₹)</label>
                  <input
                    type="number"
                    value={formData.transactionLimit}
                    onChange={(e) => setFormData({ ...formData, transactionLimit: Number.parseFloat(e.target.value) })}
                    className="w-full px-4 py-2 border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    min="0"
                  />
                  <p className="text-xs text-muted-foreground">Alert threshold for individual transactions</p>
                </div>

                <Button onClick={handleSaveSettings} className="w-full mt-4">
                  Save Settings
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="p-4">
                <h3 className="font-semibold text-blue-900 mb-3">Current Status</h3>
                <div className="space-y-3 text-sm">
                  <div>
                    <p className="text-blue-700">Monthly Salary</p>
                    <p className="font-bold text-lg">₹{user.salary?.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-blue-700">Monthly Budget</p>
                    <p className="font-bold text-lg">₹{user.monthlyBudget?.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-blue-700">Transaction Limit</p>
                    <p className="font-bold text-lg">₹{user.transactionLimit?.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-blue-700">Target Savings Rate</p>
                    <p className="font-bold text-lg">20%</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-yellow-50 border-yellow-200">
              <CardContent className="p-4">
                <div className="flex gap-2">
                  <AlertCircle className="w-5 h-5 text-yellow-700 flex-shrink-0" />
                  <div className="text-sm text-yellow-800">
                    <p className="font-semibold mb-1">Tips</p>
                    <ul className="space-y-1 text-xs">
                      <li>• Keep monthly budget at 80% of salary</li>
                      <li>• Set transaction limit to prevent overspending</li>
                      <li>• Review settings monthly</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
