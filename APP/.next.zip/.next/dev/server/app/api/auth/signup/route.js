var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/signup/route.js")
R.c("server/chunks/node_modules_next_121464f5._.js")
R.c("server/chunks/[root-of-the-server]__6f4759cd._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_signup_route_actions_3cc2654d.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/auth/signup/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/auth/signup/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
