module.exports = [
"[project]/.next-internal/server/app/expenses/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_expenses_page_actions_838a26a2.js.map