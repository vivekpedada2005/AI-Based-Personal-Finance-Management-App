"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, CheckCircle2, Target, TrendingUp } from "lucide-react"

export default function GoalsPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [goals, setGoals] = useState<any[]>([])
  const [showForm, setShowForm] = useState(false)
  const [newGoal, setNewGoal] = useState({ name: "", targetAmount: "", targetDate: "" })

  useEffect(() => {
    const token = localStorage.getItem("token")
    const userData = localStorage.getItem("user")

    if (!token || !userData) {
      router.push("/login")
      return
    }

    const parsedUser = JSON.parse(userData)
    setUser(parsedUser)

    const userEmail = parsedUser.email || "user"
    const goalsKey = `savings_goals_${userEmail}`
    const savedGoals = JSON.parse(localStorage.getItem(goalsKey) || "[]")
    setGoals(savedGoals)
  }, [router])

  const handleAddGoal = (e: React.FormEvent) => {
    e.preventDefault()

    if (!newGoal.name.trim() || !newGoal.targetAmount || !newGoal.targetDate) {
      alert("Please fill in all fields")
      return
    }

    const goal = {
      id: Date.now().toString(),
      name: newGoal.name,
      targetAmount: Number.parseFloat(newGoal.targetAmount),
      targetDate: newGoal.targetDate,
      createdDate: new Date(),
      currentAmount: 0,
    }

    const updatedGoals = [...goals, goal]
    setGoals(updatedGoals)

    const userEmail = user.email || "user"
    const goalsKey = `savings_goals_${userEmail}`
    localStorage.setItem(goalsKey, JSON.stringify(updatedGoals))

    setNewGoal({ name: "", targetAmount: "", targetDate: "" })
    setShowForm(false)
  }

  const handleDeleteGoal = (id: string) => {
    const updatedGoals = goals.filter((g) => g.id !== id)
    setGoals(updatedGoals)

    const userEmail = user.email || "user"
    const goalsKey = `savings_goals_${userEmail}`
    localStorage.setItem(goalsKey, JSON.stringify(updatedGoals))
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  const totalGoalTarget = goals.reduce((sum, g) => sum + g.targetAmount, 0)
  const completedGoals = goals.filter((g) => g.currentAmount >= g.targetAmount)

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6 animate-in fade-in">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Savings Goals
          </h1>
          <p className="text-muted-foreground">Set and track your financial targets</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Goals</p>
                  <p className="text-3xl font-bold">{goals.length}</p>
                </div>
                <Target className="w-8 h-8 text-primary opacity-30" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Combined Target</p>
                  <p className="text-3xl font-bold">₹{totalGoalTarget.toLocaleString()}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-accent opacity-30" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Completed</p>
                  <p className="text-3xl font-bold text-green-600">{completedGoals.length}</p>
                </div>
                <CheckCircle2 className="w-8 h-8 text-green-500 opacity-30" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">Your Goals</h2>
          <Button onClick={() => setShowForm(!showForm)} className="gap-2">
            <Plus className="w-4 h-4" />
            Add Goal
          </Button>
        </div>

        {showForm && (
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle>Create New Savings Goal</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddGoal} className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Goal Name</label>
                  <input
                    type="text"
                    value={newGoal.name}
                    onChange={(e) => setNewGoal({ ...newGoal, name: e.target.value })}
                    placeholder="e.g., Emergency Fund, Vacation"
                    className="w-full px-3 py-2 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Target Amount (₹)</label>
                    <input
                      type="number"
                      value={newGoal.targetAmount}
                      onChange={(e) => setNewGoal({ ...newGoal, targetAmount: e.target.value })}
                      placeholder="50000"
                      className="w-full px-3 py-2 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                      min="0"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Target Date</label>
                    <input
                      type="date"
                      value={newGoal.targetDate}
                      onChange={(e) => setNewGoal({ ...newGoal, targetDate: e.target.value })}
                      className="w-full px-3 py-2 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button type="submit" className="flex-1">
                    Create Goal
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setShowForm(false)} className="flex-1">
                    Cancel
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {goals.length === 0 ? (
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-8 text-center">
              <Target className="w-12 h-12 text-blue-600 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-semibold text-blue-900">No goals yet</p>
              <p className="text-blue-700 mt-2">Set your first savings goal to get started!</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {goals.map((goal) => {
              const progress = (goal.currentAmount / goal.targetAmount) * 100
              return (
                <Card key={goal.id} className="border-l-4 border-l-primary">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="font-semibold text-lg">{goal.name}</h3>
                        <p className="text-sm text-muted-foreground">
                          Target: {new Date(goal.targetDate).toLocaleDateString()}
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteGoal(goal.id)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        Delete
                      </Button>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">₹{goal.currentAmount.toLocaleString()}</span>
                        <span className="text-sm font-semibold">₹{goal.targetAmount.toLocaleString()}</span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div
                          className="h-2 rounded-full bg-primary transition-all"
                          style={{ width: `${Math.min(progress, 100)}%` }}
                        />
                      </div>
                      <p className="text-xs text-slate-500">{progress.toFixed(0)}% complete</p>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}
      </div>
    </DashboardLayout>
  )
}
